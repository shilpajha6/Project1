import { useEffect, useRef, useState } from "react";
import { Logo } from "./Logo";
import { api, getToken, setToken, type Briefing, type Catalog, type Story, type User } from "./api";

type Screen =
  | "splash"
  | "language"
  | "login"
  | "profession"
  | "niches"
  | "voice"
  | "schedule"
  | "notify"
  | "ready"
  | "player"
  | "discover"
  | "settings"
  | "saved"
  | "billing";

const TOTAL = 6;
const TIMES = ["6:00", "6:30", "7:00", "7:30", "8:00"];

const FALLBACK_LANGS = [
  { id: "en" as const, label: "English", native: "Stories delivered in English" },
  { id: "hi" as const, label: "हिन्दी", native: "दैनिक ब्रीफ हिंदी में" },
];

const FALLBACK_PROFESSIONS = [
  { id: "finance", label: "Finance & Trading", icon: "📈" },
  { id: "legal", label: "Legal", icon: "⚖️" },
  { id: "tech", label: "Technology", icon: "✦" },
  { id: "healthcare", label: "Healthcare", icon: "🩺" },
  { id: "consulting", label: "Consulting", icon: "🧭" },
  { id: "marketing", label: "Marketing & Media", icon: "📣" },
  { id: "policy", label: "Government & Policy", icon: "🏛️" },
  { id: "realestate", label: "Real Estate", icon: "🏠" },
  { id: "education", label: "Education", icon: "🎓" },
  { id: "founder", label: "Founder / Builder", icon: "🚀" },
];

const FALLBACK_TOPICS = [
  { id: "ai", label: "AI & Technology", color: "#7b70d8", icon: "✦" },
  { id: "markets", label: "Financial Markets", color: "#4eccc4", icon: "📈" },
  { id: "india", label: "Indian Business", color: "#ffb35c", icon: "🇮🇳" },
  { id: "politics", label: "Global Politics", color: "#9b8cff", icon: "🌍" },
  { id: "startups", label: "Startups", color: "#c084fc", icon: "🚀" },
  { id: "science", label: "Science", color: "#34d399", icon: "🧪" },
  { id: "geo", label: "Geopolitics", color: "#60a5fa", icon: "🗺️" },
  { id: "health", label: "Health & Medicine", color: "#f472b6", icon: "🩺" },
  { id: "climate", label: "Climate & Energy", color: "#4ade80", icon: "🌿" },
  { id: "sports", label: "Sports", color: "#fb923c", icon: "⚽" },
  { id: "culture", label: "Culture & Arts", color: "#e879f9", icon: "🎭" },
  { id: "legal", label: "Legal & Policy", color: "#a3a3a3", icon: "⚖️" },
];

const FALLBACK_VOICES = [
  { id: "aria", name: "Aria", locale: "en-GB", lang: "EN", style: "Warm · Unhurried · British", sample: "Good morning. Here is your briefing for today." },
  { id: "kai", name: "Kai", locale: "en-US", lang: "EN", style: "Crisp · Focused · American", sample: "Here's what moved overnight — in two minutes." },
  { id: "meera", name: "Meera", locale: "hi-IN", lang: "HI", style: "Bright · Curious · Indian", sample: "सुप्रभात। आज की ब्रीफिंग तैयार है।" },
];

function Status() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  return (
    <div className="status">
      <span>{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}</span>
      <span style={{ opacity: 0.45 }}>●●●</span>
    </div>
  );
}

function Steps({ n, total }: { n: number; total: number }) {
  return (
    <div className="progress">
      {Array.from({ length: total }, (_, i) => (
        <i key={i} className={i < n ? "on" : ""} />
      ))}
    </div>
  );
}

function OnboardBar({ step, onSkip }: { step: number; onSkip?: () => void }) {
  return (
    <>
      <div className="app-head">
        <Logo size="onboard" />
        {onSkip ? (
          <button className="skip-link" onClick={onSkip}>
            Skip
          </button>
        ) : (
          <span className="tiny">{step} / {TOTAL}</span>
        )}
      </div>
      <p className="step-kicker">Step {step} of {TOTAL}</p>
      <Steps n={step} total={TOTAL} />
    </>
  );
}

function Wave({ playing }: { playing: boolean }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => setTick((x) => x + 1), 80);
    return () => clearInterval(id);
  }, [playing]);
  return (
    <div className="wave purple wave-lg">
      {Array.from({ length: 40 }, (_, i) => (
        <i
          key={i}
          style={{ height: `${playing ? 14 + ((i * 19 + tick * 13) % 82) : 8 + (i % 7) * 5}%` }}
        />
      ))}
    </div>
  );
}

function speak(text: string, locale: string, onend: () => void) {
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = locale;
  u.rate = locale.startsWith("hi") ? 0.95 : 1;
  const found = window.speechSynthesis.getVoices().find((v) => v.lang.startsWith(locale.slice(0, 2)));
  if (found) u.voice = found;
  u.onend = onend;
  window.speechSynthesis.speak(u);
}

function Flag({ id }: { id: string }) {
  if (id === "hi") {
    return (
      <svg className="flag-svg" viewBox="0 0 40 28" aria-hidden>
        <rect width="40" height="9.4" fill="#FF9933" />
        <rect y="9.4" width="40" height="9.2" fill="#fff" />
        <rect y="18.6" width="40" height="9.4" fill="#138808" />
        <circle cx="20" cy="14" r="3.1" fill="none" stroke="#000080" strokeWidth="1.2" />
      </svg>
    );
  }
  return (
    <svg className="flag-svg" viewBox="0 0 40 28" aria-hidden>
      <rect width="40" height="28" fill="#012169" />
      <path d="M0 0l40 28M40 0L0 28" stroke="#fff" strokeWidth="6" />
      <path d="M0 0l40 28M40 0L0 28" stroke="#C8102E" strokeWidth="3" />
      <path d="M20 0v28M0 14h40" stroke="#fff" strokeWidth="8" />
      <path d="M20 0v28M0 14h40" stroke="#C8102E" strokeWidth="4" />
    </svg>
  );
}

function GoogleMark() {
  return (
    <svg viewBox="0 0 18 18" width="18" height="18">
      <path fill="#4285F4" d="M17.6 9.2c0-.6-.1-1.2-.2-1.8H9v3.4h4.8c-.2 1.1-.8 2-1.8 2.6v2.2h2.9c1.7-1.6 2.7-3.9 2.7-6.4z" />
      <path fill="#34A853" d="M9 18c2.4 0 4.5-.8 6-2.2l-2.9-2.2c-.8.6-1.9.9-3.1.9-2.4 0-4.4-1.6-5.1-3.8H.9v2.3C2.4 16.1 5.5 18 9 18z" />
      <path fill="#FBBC05" d="M3.9 10.7c-.2-.6-.3-1.2-.3-1.7s.1-1.2.3-1.7V5H.9C.3 6.2 0 7.6 0 9s.3 2.8.9 4l3-2.3z" />
      <path fill="#EA4335" d="M9 3.5c1.3 0 2.5.5 3.4 1.3l2.6-2.6C13.5.7 11.4 0 9 0 5.5 0 2.4 1.9.9 5l3 2.3C4.6 5.1 6.6 3.5 9 3.5z" />
    </svg>
  );
}

function storyCopy(duration: number) {
  if (duration <= 5) return 5;
  if (duration <= 10) return 6;
  if (duration <= 15) return 8;
  return 10;
}

export function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [catalog, setCatalog] = useState<Catalog | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [briefing, setBriefing] = useState<Briefing | null>(null);
  const [feed, setFeed] = useState<Story[]>([]);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [language, setLanguage] = useState<"en" | "hi">("en");
  const [location, setLocation] = useState(true);
  const [profession, setProfession] = useState("tech");
  const [picked, setPicked] = useState<string[]>(["ai", "markets", "startups"]);
  const [voice, setVoice] = useState("aria");
  const [duration, setDuration] = useState(5);
  const [customLen, setCustomLen] = useState(false);
  const [ampm, setAmpm] = useState<"AM" | "PM">("AM");
  const [slot, setSlot] = useState("7:00");
  const [playing, setPlaying] = useState(false);
  const [index, setIndex] = useState(0);
  const [preview, setPreview] = useState<string | null>(null);
  const [showEmail, setShowEmail] = useState(false);
  const [authMode, setAuthMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [topicFilter, setTopicFilter] = useState("all");
  const [appearance, setAppearance] = useState<"dark" | "light">("dark");
  const [offline, setOffline] = useState(false);
  const [autoAdvance, setAutoAdvance] = useState(true);
  const [pushOn, setPushOn] = useState(true);
  const [plan, setPlan] = useState<"free" | "pro" | "annual">("free");
  const [saved, setSaved] = useState<Story[]>([]);
  const playRef = useRef(false);

  useEffect(() => {
    api.catalog().then(setCatalog).catch(() => setError("Start the API with npm run dev."));
  }, []);

  useEffect(() => {
    if (screen !== "splash") return;
    const t = window.setTimeout(() => {
      setScreen((s) => (s === "splash" ? "language" : s));
    }, 1600);
    return () => window.clearTimeout(t);
  }, [screen]);

  useEffect(() => {
    if (!getToken()) return;
    void restore();
  }, []);

  const professions = catalog?.professions?.length ? catalog.professions : FALLBACK_PROFESSIONS;
  const topics = catalog?.topics?.length ? catalog.topics : FALLBACK_TOPICS;
  const voices = catalog?.voices?.length ? catalog.voices : FALLBACK_VOICES;
  const langs = catalog?.languages?.length ? catalog.languages : FALLBACK_LANGS;
  const voiceMeta = voices.find((v) => v.id === voice) ?? voices[0];
  const professionMeta = professions.find((p) => p.id === profession);
  const extraTopics = Math.max(0, picked.length - 3);

  async function restore() {
    try {
      const { user: me } = await api.me();
      await enter(me, false);
    } catch {
      setToken(null);
    }
  }

  async function enter(me: User, onboard: boolean) {
    setUser(me);
    setLanguage(me.language);
    setProfession(me.profession || "tech");
    setPicked(me.topics?.length ? me.topics : ["ai", "markets", "startups"]);
    setVoice(me.voice || "aria");
    setDuration(me.duration || 5);
    setLocation(me.location);
    if (onboard || !me.profession) {
      setScreen("profession");
      return;
    }
    await openPlayer();
  }

  async function openPlayer() {
    const brief = await api.briefing();
    setBriefing(brief);
    const { stories } = await api.feed();
    setFeed(stories);
    setSaved((cur) => (cur.length ? cur : stories.slice(0, 3)));
    setIndex(0);
    setScreen("player");
  }

  async function passwordAuth() {
    setBusy(true);
    setError("");
    try {
      const result =
        authMode === "up"
          ? await api.register({ name: name.trim(), email, password })
          : await api.login({ email, password });
      setToken(result.token);
      if (authMode === "up") await api.saveMe({ language, location });
      const { user: me } = await api.me();
      await enter(me, true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setBusy(false);
    }
  }

  async function googleSignIn() {
    setBusy(true);
    setError("");
    try {
      const result = await api.google({ name: "Aarav Sharma", email: "google.user@nuzio.app" });
      setToken(result.token);
      await api.saveMe({ language, location });
      const { user: me } = await api.me();
      await enter(me, true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Google sign-in failed.");
    } finally {
      setBusy(false);
    }
  }

  async function demoSignIn() {
    setBusy(true);
    setError("");
    try {
      const result = await api.login({ email: "demo@nuzio.app", password: "nuzio123" });
      setToken(result.token);
      await enter(result.user, true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign in failed.");
    } finally {
      setBusy(false);
    }
  }

  function signOut() {
    stop();
    setToken(null);
    setUser(null);
    setBriefing(null);
    setFeed([]);
    setScreen("splash");
  }

  async function savePrefs(next: Screen) {
    setBusy(true);
    setError("");
    try {
      const { user: me } = await api.saveMe({
        language,
        location,
        profession,
        topics: picked,
        voice,
        duration,
      });
      setUser(me);
      setScreen(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not save.");
    } finally {
      setBusy(false);
    }
  }

  function stop() {
    playRef.current = false;
    window.speechSynthesis.cancel();
    setPlaying(false);
    setPreview(null);
  }

  function playFrom(start: number) {
    if (!briefing) return;
    playRef.current = true;
    setPlaying(true);
    const run = (i: number) => {
      if (!playRef.current || !briefing.stories[i]) {
        stop();
        return;
      }
      setIndex(i);
      const s = briefing.stories[i];
      speak(`${s.title}. ${s.summary} ${s.deepDive}`, briefing.voice.locale, () => run(i + 1));
    };
    run(start);
  }

  function previewVoice(id: string, sample: string, locale: string) {
    if (preview === id) {
      stop();
      return;
    }
    setPreview(id);
    speak(sample, locale, () => setPreview(null));
  }

  const story = briefing?.stories[index];
  const topicLabel = (id: string) => topics.find((t) => t.id === id)?.label || id;
  const briefDate = new Date()
    .toLocaleDateString(language === "hi" ? "hi-IN" : "en-GB", {
      weekday: "long",
      day: "numeric",
      month: "short",
    })
    .toUpperCase();
  const visibleFeed = (feed.length ? feed : briefing?.stories || []).filter(
    (s) => topicFilter === "all" || s.tags.includes(topicFilter),
  );
  const firstName = (user?.name || "there").split(" ")[0];
  const briefClock = `${slot} ${ampm}`;

  function goNav(next: Screen) {
    if (next !== "player") stop();
    setScreen(next);
  }

  return (
    <div className="stage">
      <div className={`phone ${appearance}`}>
        {screen === "splash" && (
          <button className="screen splash" onClick={() => setScreen("language")}>
            <div className="glow center" />
            <Logo size="splash" glow />
            <p className="tagline" style={{ fontSize: 28 }}>
              News on go
            </p>
          </button>
        )}

        {screen === "language" && (
          <div className="screen">
            <div className="glow wide" />
            <Status />
            <div style={{ display: "flex", justifyContent: "center", margin: "8px 0 18px" }}>
              <Logo size="language" glow />
            </div>
            <h2>
              Choose your
              <br />
              <em>language</em>
            </h2>
            <p className="lede">Select the language for your daily brief.</p>
            <div className="scroll stack" style={{ marginTop: 18 }}>
              {langs.map((l) => (
                <button
                  key={l.id}
                  className={`lang-card ${language === l.id ? "on" : ""}`}
                  onClick={() => {
                    setLanguage(l.id as "en" | "hi");
                    setVoice(l.id === "hi" ? "meera" : "aria");
                  }}
                >
                  <Flag id={l.id} />
                  <div className="grow">
                    <b>{l.label}</b>
                    <p className="muted">{l.native}</p>
                  </div>
                  <span className="radio">
                    <span />
                  </span>
                </button>
              ))}
              <div className="perm">
                <div className="grow">
                  <b>Enable Location</b>
                  <p className="muted">Personalise news tailored for your city.</p>
                </div>
                <button className={`switch ${location ? "on" : ""}`} onClick={() => setLocation((v) => !v)}>
                  <span />
                </button>
              </div>
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" onClick={() => setScreen("login")}>
                Continue →
              </button>
            </div>
          </div>
        )}

        {screen === "login" && (
          <div className="screen">
            <div className="glow wide" />
            <Status />
            <div style={{ display: "flex", justifyContent: "center", marginTop: 8 }}>
              <Logo size="onboard" />
            </div>
            <div className="login-hero">
              <h1>
                Good morning.
                <br />
                <em>News on go.</em>
              </h1>
              <p className="lede">Personalised audio news for Indian professionals — crushed fresh every morning.</p>
              {error && <p className="form-error">{error}</p>}
              {showEmail && (
                <div className="auth-fields">
                  {authMode === "up" && (
                    <input className="field" placeholder="Full name" value={name} onChange={(e) => setName(e.target.value)} />
                  )}
                  <input className="field" type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                  <input className="field" type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                  <button className="btn btn-p" disabled={busy} onClick={() => void passwordAuth()}>
                    {authMode === "up" ? "Create account" : "Sign in"}
                  </button>
                  <button className="linkish" onClick={() => setAuthMode((m) => (m === "in" ? "up" : "in"))}>
                    {authMode === "in" ? "Create an account" : "Already have an account? Sign in"}
                  </button>
                </div>
              )}
            </div>
            <div className="footer-cta">
              <button className="btn-google" disabled={busy} onClick={() => void googleSignIn()}>
                <GoogleMark />
                Continue with Google
              </button>
              <button className="linkish" onClick={() => void demoSignIn()}>
                Use demo account
              </button>
              <button className="linkish" onClick={() => setShowEmail((v) => !v)}>
                {showEmail ? "Hide email sign-in" : "Sign in with email"}
              </button>
              <p className="legal">By continuing you agree to our Terms · Privacy Policy</p>
            </div>
          </div>
        )}

        {screen === "profession" && (
          <div className="screen">
            <Status />
            <OnboardBar step={1} />
            <h2>
              What’s your
              <br />
              <em>profession?</em>
            </h2>
            <p className="lede">We’ll tune every brief to what actually moves your day.</p>
            <div className="scroll" style={{ marginTop: 16 }}>
              <div className="grid-2">
                {professions.map((p) => (
                  <button
                    key={p.id}
                    className={`card ${profession === p.id ? "on" : ""}`}
                    onClick={() => setProfession(p.id)}
                  >
                    <div className="ico">{p.icon}</div>
                    <b>{p.label}</b>
                  </button>
                ))}
              </div>
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" disabled={busy} onClick={() => void savePrefs("niches")}>
                Continue →
              </button>
            </div>
          </div>
        )}

        {screen === "niches" && (
          <div className="screen">
            <Status />
            <OnboardBar step={2} />
            <h2>
              What moves
              <br />
              <em>your world?</em>
            </h2>
            <p className="lede">Pick up to 7 niches.</p>
            <div className="scroll" style={{ marginTop: 16 }}>
              <div className="chips">
                {topics.map((t) => {
                  const on = picked.includes(t.id);
                  return (
                    <button
                      key={t.id}
                      className={`chip ${on ? "on" : ""}`}
                      style={on ? { borderColor: t.color } : undefined}
                      onClick={() =>
                        setPicked((cur) =>
                          on ? cur.filter((x) => x !== t.id) : cur.length >= 7 ? cur : [...cur, t.id],
                        )
                      }
                    >
                      {t.icon || ""} {t.label}
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" disabled={!picked.length || busy} onClick={() => void savePrefs("voice")}>
                Continue →
              </button>
            </div>
          </div>
        )}

        {screen === "voice" && (
          <div className="screen">
            <Status />
            <OnboardBar step={3} onSkip={() => void savePrefs("schedule")} />
            <h2>
              Pick a
              <br />
              narrator <em>voice.</em>
            </h2>
            <p className="lede">Tap ▶ to hear a 10-second sample.</p>
            <div className="scroll stack" style={{ marginTop: 16 }}>
              {voices.map((v) => (
                <div key={v.id} className={`voice-row ${voice === v.id ? "on" : ""}`}>
                  <div className="avatar">{v.name[0]}</div>
                  <button className="grow" style={{ textAlign: "left" }} onClick={() => setVoice(v.id)}>
                    <b>
                      {v.name} <span className="pill">{v.lang}</span>
                    </b>
                    <p className="muted">{v.style}</p>
                  </button>
                  <span className="tick">✓</span>
                  <button className="sq-play" onClick={() => previewVoice(v.id, v.sample || v.name, v.locale)}>
                    {preview === v.id ? "❚❚" : "▶"}
                  </button>
                </div>
              ))}
              <p className="step-kicker" style={{ marginTop: 8 }}>Brief length</p>
              <h2 style={{ fontSize: 26 }}>
                How long is
                <br />
                <em>your morning?</em>
              </h2>
              <p className="lede" style={{ marginTop: 8 }}>
                Set your ideal brief length.
              </p>
              <div className="lengths" style={{ marginTop: 12 }}>
                {[5, 10, 15].map((d) => (
                  <button
                    key={d}
                    className={!customLen && duration === d ? "on" : ""}
                    onClick={() => {
                      setCustomLen(false);
                      setDuration(d);
                    }}
                  >
                    {d} min
                  </button>
                ))}
                <button
                  className={customLen ? "on" : ""}
                  onClick={() => {
                    setCustomLen(true);
                    setDuration(20);
                  }}
                >
                  Custom
                </button>
              </div>
              {error && <p className="form-error">{error}</p>}
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" disabled={busy} onClick={() => void savePrefs("schedule")}>
                Continue with {voiceMeta?.name} · {storyCopy(duration)} stories
              </button>
            </div>
          </div>
        )}

        {screen === "schedule" && (
          <div className="screen">
            <Status />
            <OnboardBar step={4} onSkip={() => setScreen("notify")} />
            <h2>
              When do you
              <br />
              <em>want your brief?</em>
            </h2>
            <p className="lede">Nuzio will have your brief ready and waiting each morning.</p>
            <div className="ampm">
              <button className={ampm === "AM" ? "on" : ""} onClick={() => setAmpm("AM")}>
                AM
              </button>
              <button className={ampm === "PM" ? "on" : ""} onClick={() => setAmpm("PM")}>
                PM
              </button>
            </div>
            <div className="scroll">
              {TIMES.map((t) => (
                <button key={t} className={`time-slot ${slot === t ? "on" : ""}`} onClick={() => setSlot(t)}>
                  {t}
                  {slot === t ? <small>{ampm}</small> : null}
                </button>
              ))}
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" onClick={() => setScreen("notify")}>
                Continue →
              </button>
            </div>
          </div>
        )}

        {screen === "notify" && (
          <div className="screen">
            <Status />
            <OnboardBar step={5} onSkip={() => setScreen("ready")} />
            <h2>
              Stay in the
              <br />
              <em>loop.</em>
            </h2>
            <p className="lede">Turn on notifications so you never miss your brief.</p>
            <div className="scroll stack" style={{ marginTop: 20 }}>
              <div className="profile-row">
                <div className="avatar">N</div>
                <div className="grow">
                  <b>Your morning brief is ready</b>
                  <p className="muted">
                    {picked.slice(0, 3).map(topicLabel).join(", ")} · {voiceMeta?.name} · {slot} {ampm}
                  </p>
                </div>
                <span className="tiny">now</span>
              </div>
              <p className="step-kicker">What you’ll receive</p>
              <div className="profile-row">
                <span>☀️</span>
                <div className="grow">
                  <b>Morning brief ready</b>
                  <p className="muted">Your daily audio briefing is waiting.</p>
                </div>
                <span className="tiny">Daily · {briefClock}</span>
              </div>
              <div className="profile-row">
                <span>⚡</span>
                <div className="grow">
                  <b>Breaking story</b>
                  <p className="muted">The story you just need in your niches.</p>
                </div>
                <span className="tiny">When it happens</span>
              </div>
            </div>
            <div className="footer-cta">
              <button className="btn btn-p" onClick={() => setScreen("ready")}>
                Allow notifications
              </button>
              <button className="linkish" onClick={() => setScreen("ready")}>
                Not now
              </button>
            </div>
          </div>
        )}

        {screen === "ready" && (
          <div className="screen">
            <Status />
            <div className="scroll" style={{ textAlign: "center", paddingTop: 24 }}>
              <div className="ring" style={{ ["--p" as string]: "100%" }}>
                <div className="check">✓</div>
              </div>
              <p className="step-kicker">All set</p>
              <h2>
                You’re ready,
                <br />
                <em>{firstName}.</em>
              </h2>
              <p className="lede" style={{ margin: "12px auto 22px" }}>
                Your first brief will be ready tomorrow at {briefClock}.
                <br />
                We’re already curating.
              </p>
              <p className="step-kicker" style={{ textAlign: "left" }}>Your brief profile</p>
              <div className="stack" style={{ textAlign: "left" }}>
                <div className="profile-row">
                  <span>✦</span>
                  <b>{professionMeta?.label || "Technology"}</b>
                </div>
                <div className="profile-row">
                  <span>◆</span>
                  <b>
                    {picked.slice(0, 3).map(topicLabel).join(", ")}
                    {extraTopics ? ` +${extraTopics}` : ""}
                  </b>
                </div>
                <div className="profile-row">
                  <span>♪</span>
                  <b>
                    {voiceMeta?.name} · {voiceMeta?.style?.split(" · ")[0]}
                  </b>
                </div>
                <div className="profile-row">
                  <span>⏱</span>
                  <b>
                    {storyCopy(duration)} stories · ~{duration} min
                  </b>
                </div>
                <div className="profile-row">
                  <span>✓</span>
                  <b>Daily at {briefClock}</b>
                </div>
              </div>
            </div>
            <div className="footer-cta">
              <button
                className="btn btn-teal"
                disabled={busy}
                onClick={() => {
                  setBusy(true);
                  void openPlayer().finally(() => setBusy(false));
                }}
              >
                Start listening →
              </button>
            </div>
          </div>
        )}

        {screen === "player" && user && briefing && story && (
          <div className="screen" style={{ paddingBottom: 0 }}>
            <div className="glow" />
            <Status />
            <div className="app-head">
              <Logo size="app" />
              <button className="tiny" onClick={signOut}>
                Sign out
              </button>
            </div>
            <div className="chips" style={{ marginBottom: 12 }}>
              {user.topics.slice(0, 4).map((id) => (
                <span key={id} className="pill">
                  {topicLabel(id)}
                </span>
              ))}
            </div>
            <div className="scroll">
              <div className="kick">{briefDate} · Morning brief</div>
              <h2>
                Good morning, {firstName} —{" "}
                <em>{briefing.stories.length} things.</em>
              </h2>
              <p className="muted">
                Audio · {briefing.voice.name} · {briefing.minutes}:00
              </p>
              <Wave playing={playing} />
              <div className="story-meta">
                {story.tags.slice(0, 1).map((t) => (
                  <span key={t} className="pill">
                    {topicLabel(t)}
                  </span>
                ))}
                <a className="source-chip" href={story.sourceUrl} target="_blank" rel="noreferrer">
                  {story.source}
                  <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
                    <path d="M3 9L9 3M5 3h4v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                  </svg>
                </a>
              </div>
              <p className="now-title">{story.title}</p>
              <div className="controls">
                <button className="skip" onClick={() => playFrom(Math.max(0, index - 1))}>
                  ↺
                </button>
                <button className="play" onClick={() => (playing ? stop() : playFrom(index))}>
                  {playing ? "❚❚" : "▶"}
                </button>
                <button className="skip" onClick={() => playFrom(Math.min(briefing.stories.length - 1, index + 1))}>
                  ↻
                </button>
              </div>
            </div>
            <Nav
              tab="player"
              playing={playing}
              onPlay={() => (playing ? stop() : playFrom(index))}
              onDiscover={() => goNav("discover")}
              onSettings={() => goNav("settings")}
            />
          </div>
        )}

        {screen === "discover" && (
          <div className="screen" style={{ paddingBottom: 0 }}>
            <Status />
            <div className="app-head">
              <Logo size="app" />
              <span className="tiny">Discover</span>
            </div>
            <h2>Discover</h2>
            <p className="lede">Hacker-style — scrape the world.</p>
            <div className="chips" style={{ margin: "10px 0" }}>
              <button className={`chip ${topicFilter === "all" ? "on" : ""}`} onClick={() => setTopicFilter("all")}>
                All
              </button>
              {user?.topics.map((id) => (
                <button
                  key={id}
                  className={`chip ${topicFilter === id ? "on" : ""}`}
                  onClick={() => setTopicFilter(id)}
                >
                  {topicLabel(id)}
                </button>
              ))}
            </div>
            <div className="scroll stack">
              {visibleFeed.map((s) => (
                <article key={s.id} className="card">
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 8 }}>
                    {s.tags.slice(0, 1).map((t) => (
                      <span key={t} className="pill">
                        {topicLabel(t)}
                      </span>
                    ))}
                    <a className="source-chip" href={s.sourceUrl} target="_blank" rel="noreferrer">
                      {s.source}
                      <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
                        <path d="M3 9L9 3M5 3h4v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
                      </svg>
                    </a>
                  </div>
                  <b style={{ fontSize: 16 }}>{s.title}</b>
                  <p>{s.summary}</p>
                  <button
                    className="btn btn-p"
                    style={{ marginTop: 12, padding: "10px 14px" }}
                    onClick={() => {
                      const i = briefing?.stories.findIndex((x) => x.id === s.id) ?? 0;
                      setScreen("player");
                      if (i >= 0) {
                        setIndex(Math.max(0, i));
                        playFrom(Math.max(0, i));
                      }
                    }}
                  >
                    Listen
                  </button>
                </article>
              ))}
            </div>
            <Nav
              tab="discover"
              playing={playing}
              onPlay={() => {
                setScreen("player");
                if (briefing) playFrom(index);
              }}
              onDiscover={() => goNav("discover")}
              onSettings={() => goNav("settings")}
            />
          </div>
        )}

        {screen === "settings" && user && (
          <div className="screen" style={{ paddingBottom: 0 }}>
            <Status />
            <div className="app-head">
              <Logo size="app" />
              <div className="head-icons">
                <span className="ico-btn">💬</span>
                <span className="ico-btn">🔔</span>
              </div>
            </div>
            <div className="scroll">
              <div className="profile-hero">
                <div className="avatar lg">{user.name[0]}</div>
                <div className="grow">
                  <b className="name-lg">{user.name}</b>
                  <p className="muted">
                    {professionMeta?.label || "Technology"}
                    {location ? " · Mumbai, India" : ""}
                  </p>
                </div>
                <button className="tiny" onClick={() => setScreen("profession")}>
                  Edit →
                </button>
              </div>
              <button className="menu-card" onClick={() => setScreen("saved")}>
                <span className="menu-ico">⚡</span>
                <div className="grow">
                  <b>Saved stories</b>
                  <p className="muted">{saved.length} saved</p>
                </div>
              </button>
              <button className="menu-card" onClick={() => setScreen("billing")}>
                <span className="menu-ico">▤</span>
                <div className="grow">
                  <b>Plan & billing</b>
                  <p className="muted">{plan === "free" ? "Free — upgrade for unlimited" : plan === "pro" ? "Pro · ₹79/mo" : "Pro Annual"}</p>
                </div>
              </button>
              <p className="step-kicker" style={{ marginTop: 18 }}>Appearance</p>
              <div className="theme-seg">
                <button className={appearance === "dark" ? "on" : ""} onClick={() => setAppearance("dark")}>
                  Dark
                </button>
                <button className={appearance === "light" ? "on" : ""} onClick={() => setAppearance("light")}>
                  Light
                </button>
              </div>
              <div className="stack" style={{ marginTop: 14 }}>
                <div className="menu-card static">
                  <span className="menu-ico">↓</span>
                  <div className="grow">
                    <b>Offline mode</b>
                    <p className="muted">Download briefs for the commute</p>
                  </div>
                  <button className={`switch ${offline ? "on" : ""}`} onClick={() => setOffline((v) => !v)}>
                    <span />
                  </button>
                </div>
                <div className="menu-card static">
                  <span className="menu-ico">⏭</span>
                  <div className="grow">
                    <b>Auto-advance</b>
                    <p className="muted">Play the next story automatically</p>
                  </div>
                  <button className={`switch ${autoAdvance ? "on" : ""}`} onClick={() => setAutoAdvance((v) => !v)}>
                    <span />
                  </button>
                </div>
                <div className="menu-card static">
                  <span className="menu-ico">🔔</span>
                  <div className="grow">
                    <b>Push notifications</b>
                    <p className="muted">Brief drops & breaking news</p>
                  </div>
                  <button className={`switch ${pushOn ? "on" : ""}`} onClick={() => setPushOn((v) => !v)}>
                    <span />
                  </button>
                </div>
              </div>
              <p className="step-kicker" style={{ marginTop: 18 }}>Brief length</p>
              <div className="lengths">
                {[5, 10, 30].map((d) => (
                  <button
                    key={d}
                    className={duration === d ? "on" : ""}
                    onClick={() => {
                      setDuration(d);
                      void api.saveMe({ duration: d });
                    }}
                  >
                    {d} min
                  </button>
                ))}
              </div>
            </div>
            <Nav
              tab="settings"
              playing={playing}
              onPlay={() => {
                setScreen("player");
                if (briefing) playFrom(index);
              }}
              onDiscover={() => goNav("discover")}
              onSettings={() => goNav("settings")}
            />
          </div>
        )}

        {screen === "saved" && (
          <div className="screen" style={{ paddingBottom: 0 }}>
            <Status />
            <div className="app-head">
              <button className="back" onClick={() => setScreen("settings")}>
                ←
              </button>
              <Logo size="app" />
              <span className="tiny">{saved.length} saved</span>
            </div>
            <h2>
              Saved <em>stories</em>
            </h2>
            <div className="scroll stack" style={{ marginTop: 16 }}>
              {saved.map((s) => (
                <article key={s.id} className="card">
                  <b>{s.title}</b>
                  <p>{s.summary}</p>
                </article>
              ))}
              {!saved.length && <p className="lede">Stories you save will land here.</p>}
            </div>
            <Nav
              tab="settings"
              playing={playing}
              onPlay={() => setScreen("player")}
              onDiscover={() => goNav("discover")}
              onSettings={() => goNav("settings")}
            />
          </div>
        )}

        {screen === "billing" && (
          <div className="screen" style={{ paddingBottom: 0 }}>
            <Status />
            <div className="app-head">
              <button className="back" onClick={() => setScreen("settings")}>
                ←
              </button>
              <Logo size="app" />
              <div className="head-icons">
                <span className="ico-btn">💬</span>
                <span className="ico-btn">🔔</span>
              </div>
            </div>
            <h2>
              Plan & <em>billing</em>
            </h2>
            <p className="lede">Start free. Upgrade when mornings pay for themselves.</p>
            <div className="scroll stack" style={{ marginTop: 16 }}>
              <div className={`plan-card ${plan === "free" ? "on" : ""}`}>
                <b>Free</b>
                <p className="price-lg">₹0<span>/mo</span></p>
                <p className="muted">5 article summaries per niche daily. Ad supported. Push notifications.</p>
                {plan === "free" && <span className="plan-status">Current plan</span>}
              </div>
              <div className={`plan-card pro ${plan === "pro" ? "on" : ""}`}>
                <span className="badge-launch">Launch offer</span>
                <b>Pro</b>
                <p className="price-lg teal">₹79<span>/mo</span></p>
                <p className="muted">Unlimited custom briefings, premium AI voices, multi-language support.</p>
                <button className="btn btn-teal" style={{ marginTop: 14 }} onClick={() => setPlan("pro")}>
                  {plan === "pro" ? "Current plan" : "Upgrade to Pro"}
                </button>
              </div>
              <div className={`plan-card ${plan === "annual" ? "on" : ""}`}>
                <b>Pro Annual</b>
                <p className="price-lg">₹1,499<span>/yr</span></p>
                <p className="muted">All Pro benefits, offline mode, priority features. Locks in.</p>
                {plan !== "annual" && (
                  <button className="btn btn-g" style={{ marginTop: 14 }} onClick={() => setPlan("annual")}>
                    Switch to annual
                  </button>
                )}
                {plan === "annual" && <span className="plan-status">Current plan</span>}
              </div>
            </div>
            <Nav
              tab="settings"
              playing={playing}
              onPlay={() => setScreen("player")}
              onDiscover={() => goNav("discover")}
              onSettings={() => goNav("settings")}
            />
          </div>
        )}
      </div>
    </div>
  );
}

function Nav({
  tab,
  playing,
  onPlay,
  onDiscover,
  onSettings,
}: {
  tab: "player" | "discover" | "settings";
  playing: boolean;
  onPlay: () => void;
  onDiscover: () => void;
  onSettings: () => void;
}) {
  return (
    <nav className="nav nav-play">
      <button className={tab === "discover" ? "on" : ""} onClick={onDiscover}>
        Discover
      </button>
      <button className="play dock" onClick={onPlay} aria-label="Play">
        {playing && tab === "player" ? "❚❚" : "▶"}
      </button>
      <button className={tab === "settings" ? "on teal" : ""} onClick={onSettings}>
        Settings
      </button>
    </nav>
  );
}
