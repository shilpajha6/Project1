export type User = {
  id: string;
  name: string;
  email: string;
  profession: string;
  topics: string[];
  language: "en" | "hi";
  duration: number;
  voice: string;
  location: boolean;
};

export type Story = {
  id: string;
  title: string;
  summary: string;
  deepDive: string;
  source: string;
  sourceUrl: string;
  minutes: number;
  tags: string[];
  profession: string;
};

export type Briefing = {
  date: string;
  title: string;
  language: "en" | "hi";
  duration: number;
  minutes: number;
  voice: { id: string; name: string; locale: string; lang: string; style?: string };
  stories: Story[];
};

export type Catalog = {
  professions: { id: string; label: string; icon: string }[];
  languages: { id: string; label: string; native?: string }[];
  voices: { id: string; name: string; locale: string; lang: string; style?: string; sample?: string }[];
  topics: { id: string; label: string; color: string; icon?: string }[];
  durations: number[];
};

const TOKEN_KEY = "nuzio_token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string | null) {
  if (token) localStorage.setItem(TOKEN_KEY, token);
  else localStorage.removeItem(TOKEN_KEY);
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  headers.set("Content-Type", "application/json");
  const token = getToken();
  if (token) headers.set("Authorization", `Bearer ${token}`);
  const res = await fetch(path, { ...init, headers });
  const data = (await res.json().catch(() => ({}))) as T & { error?: string };
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export type Prefs = Partial<Pick<User, "profession" | "topics" | "language" | "duration" | "voice" | "location">>;

export const api = {
  catalog: () => request<Catalog>("/api/catalog"),
  register: (body: { name: string; email: string; password: string }) =>
    request<{ token: string; user: User }>("/api/auth/register", { method: "POST", body: JSON.stringify(body) }),
  login: (body: { email: string; password: string }) =>
    request<{ token: string; user: User }>("/api/auth/login", { method: "POST", body: JSON.stringify(body) }),
  google: (body: { name?: string; email?: string }) =>
    request<{ token: string; user: User }>("/api/auth/google", { method: "POST", body: JSON.stringify(body) }),
  me: () => request<{ user: User }>("/api/me"),
  saveMe: (body: Prefs) => request<{ user: User }>("/api/me", { method: "PATCH", body: JSON.stringify(body) }),
  briefing: () => request<Briefing>("/api/briefing"),
  feed: () => request<{ stories: Story[] }>("/api/feed"),
};
