type LogoSize = "canvas" | "onboard" | "app" | "language" | "login" | "splash";

const SIZES: Record<LogoSize, number> = {
  canvas: 28,
  onboard: 38,
  app: 44,
  language: 76,
  login: 96,
  splash: 110,
};

export function Logo({
  size,
  glow = false,
}: {
  size: LogoSize | number;
  glow?: boolean;
}) {
  const px = typeof size === "number" ? size : SIZES[size];
  return (
    <span className={`brand-logo${glow ? " is-glow" : ""}`} style={{ width: px, height: px }}>
      <img src="/logo.svg" alt="" width={px} height={px} />
    </span>
  );
}
