import { createServer } from "node:http";
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import express from "express";
import cors from "cors";
import jwt from "jsonwebtoken";
import {
  buildBriefing,
  languages,
  professions,
  topics,
  voices,
} from "./news.ts";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "data");
const USERS_FILE = join(DATA_DIR, "users.json");
const PORT = Number(process.env.PORT || 8787);
const JWT_SECRET = process.env.JWT_SECRET || "nuzio-dev-secret";

type User = {
  id: string;
  name: string;
  email: string;
  passwordHash: string | null;
  provider: "password" | "google";
  profession: string;
  topics: string[];
  language: "en" | "hi";
  duration: number;
  voice: string;
  location: boolean;
};

function loadUsers(): User[] {
  if (!existsSync(USERS_FILE)) return [];
  return JSON.parse(readFileSync(USERS_FILE, "utf8")) as User[];
}

function saveUsers(users: User[]) {
  mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 32).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  const next = scryptSync(password, salt, 32);
  const prev = Buffer.from(hash, "hex");
  return prev.length === next.length && timingSafeEqual(prev, next);
}

function tokenFor(user: User) {
  return jwt.sign({ sub: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" });
}

function publicUser(user: User) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    profession: user.profession,
    topics: user.topics || [],
    language: user.language,
    duration: user.duration,
    voice: user.voice,
    location: !!user.location,
  };
}

function seed() {
  const users = loadUsers();
  let demo = users.find((u) => u.email === "demo@nuzio.app");
  if (!demo) {
    users.push({
      id: "u_demo",
      name: "Aarav Sharma",
      email: "demo@nuzio.app",
      passwordHash: hashPassword("nuzio123"),
      provider: "password",
      profession: "tech",
      topics: ["ai", "markets", "startups"],
      language: "en",
      duration: 10,
      voice: "aria",
      location: true,
    });
  } else {
    demo.name = "Aarav Sharma";
    demo.profession = "tech";
    demo.topics = ["ai", "markets", "startups"];
    demo.language = "en";
    demo.duration = 10;
    demo.voice = "aria";
    demo.location = true;
  }
  for (const u of users) {
    if (!Array.isArray(u.topics)) u.topics = [];
  }
  saveUsers(users);
}

function auth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const header = req.headers.authorization || "";
  const raw = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!raw) {
    res.status(401).json({ error: "Sign in required." });
    return;
  }
  try {
    const payload = jwt.verify(raw, JWT_SECRET) as { sub: string };
    const user = loadUsers().find((u) => u.id === payload.sub);
    if (!user) {
      res.status(401).json({ error: "Session expired." });
      return;
    }
    (req as express.Request & { user: User }).user = user;
    next();
  } catch {
    res.status(401).json({ error: "Session expired." });
  }
}

seed();

const app = express();
app.use(cors({ origin: true }));
app.use(express.json());

app.get("/api/health", (_req, res) => {
  res.json({ ok: true });
});

app.get("/api/catalog", (_req, res) => {
  res.json({ professions, languages, voices, topics, durations: [5, 10, 15, 30] });
});

app.post("/api/auth/register", (req, res) => {
  const name = String(req.body?.name || "").trim();
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  if (!name || !email || password.length < 6) {
    res.status(400).json({ error: "Name, email, and a password of 6+ characters are required." });
    return;
  }
  const users = loadUsers();
  if (users.some((u) => u.email === email)) {
    res.status(409).json({ error: "An account with that email already exists." });
    return;
  }
  const user: User = {
    id: `u_${randomBytes(6).toString("hex")}`,
    name,
    email,
    passwordHash: hashPassword(password),
    provider: "password",
    profession: "",
    topics: [],
    language: "en",
    duration: 10,
    voice: "aria",
    location: false,
  };
  users.push(user);
  saveUsers(users);
  res.json({ token: tokenFor(user), user: publicUser(user) });
});

app.post("/api/auth/login", (req, res) => {
  const email = String(req.body?.email || "").trim().toLowerCase();
  const password = String(req.body?.password || "");
  const user = loadUsers().find((u) => u.email === email);
  if (!user?.passwordHash || !verifyPassword(password, user.passwordHash)) {
    res.status(401).json({ error: "Email or password is incorrect." });
    return;
  }
  res.json({ token: tokenFor(user), user: publicUser(user) });
});

app.post("/api/auth/google", (req, res) => {
  const name = String(req.body?.name || "Google user").trim();
  const email = String(req.body?.email || "google.user@nuzio.app").trim().toLowerCase();
  const users = loadUsers();
  let user = users.find((u) => u.email === email);
  if (!user) {
    user = {
      id: `u_${randomBytes(6).toString("hex")}`,
      name,
      email,
      passwordHash: null,
      provider: "google",
      profession: "",
      topics: [],
      language: "en",
      duration: 10,
      voice: "aria",
      location: false,
    };
    users.push(user);
    saveUsers(users);
  }
  res.json({ token: tokenFor(user), user: publicUser(user) });
});

app.get("/api/me", auth, (req, res) => {
  const user = (req as express.Request & { user: User }).user;
  res.json({ user: publicUser(user) });
});

app.patch("/api/me", auth, (req, res) => {
  const current = (req as express.Request & { user: User }).user;
  const users = loadUsers();
  const user = users.find((u) => u.id === current.id)!;
  if (req.body?.profession) user.profession = String(req.body.profession);
  if (Array.isArray(req.body?.topics)) user.topics = req.body.topics.map(String);
  if (req.body?.language === "en" || req.body?.language === "hi") user.language = req.body.language;
  if (req.body?.duration) user.duration = Number(req.body.duration);
  if (req.body?.voice) user.voice = String(req.body.voice);
  if (typeof req.body?.location === "boolean") user.location = req.body.location;
  saveUsers(users);
  res.json({ user: publicUser(user) });
});

app.get("/api/briefing", auth, (req, res) => {
  const user = (req as express.Request & { user: User }).user;
  if (!user.profession) {
    res.status(409).json({ error: "Choose a profession to personalise your brief." });
    return;
  }
  const stories = buildBriefing(user.profession, user.language, user.duration, user.topics || []);
  const voice = voices.find((v) => v.id === user.voice) ?? voices[0];
  const title =
    user.language === "hi"
      ? `${professions.find((p) => p.id === user.profession)?.label} ब्रीफ`
      : `Morning Brief · ${professions.find((p) => p.id === user.profession)?.label}`;
  res.json({
    date: new Date().toISOString().slice(0, 10),
    title,
    language: user.language,
    duration: user.duration,
    voice,
    minutes: stories.reduce((n, s) => n + s.minutes, 0),
    stories,
  });
});

app.get("/api/feed", auth, (req, res) => {
  const user = (req as express.Request & { user: User }).user;
  const stories = buildBriefing(user.profession || "tech", user.language, 30, user.topics || []);
  res.json({ stories });
});

createServer(app).listen(PORT, "127.0.0.1", () => {
  console.log(`Nuzio API http://127.0.0.1:${PORT}`);
});
