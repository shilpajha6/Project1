export const professions = [
  { id: "finance", label: "Finance & Trading", icon: "📈" },
  { id: "legal", label: "Legal", icon: "⚖️" },
  { id: "tech", label: "Technology", icon: "✦" },
  { id: "healthcare", label: "Healthcare", icon: "🩺" },
  { id: "consulting", label: "Consulting", icon: "🧭" },
  { id: "marketing", label: "Marketing & Media", icon: "📣" },
  { id: "policy", label: "Government & Policy", icon: "🏛️" },
  { id: "realestate", label: "Real Estate", icon: "🏠" },
  { id: "education", label: "Education", icon: "🎓" },
  { id: "founder", label: "Founder / Builder", icon: "🚀" },
] as const;

export const topics = [
  { id: "ai", label: "AI & Technology", color: "#7b70d8", icon: "✦" },
  { id: "markets", label: "Financial Markets", color: "#4eccc4", icon: "📈" },
  { id: "india", label: "Indian Business", color: "#ffb35c", icon: "🇮🇳" },
  { id: "politics", label: "Global Politics", color: "#9b8cff", icon: "🌍" },
  { id: "startups", label: "Startups", color: "#c084fc", icon: "🚀" },
  { id: "science", label: "Science", color: "#34d399", icon: "🧪" },
  { id: "geo", label: "Geopolitics", color: "#60a5fa", icon: "🗺️" },
  { id: "health", label: "Health & Medicine", color: "#f472b6", icon: "🩺" },
  { id: "climate", label: "Climate & Energy", color: "#4ade80", icon: "🌿" },
  { id: "sports", label: "Sports", color: "#fb923c", icon: "⚽" },
  { id: "culture", label: "Culture & Arts", color: "#e879f9", icon: "🎭" },
  { id: "legal", label: "Legal & Policy", color: "#a3a3a3", icon: "⚖️" },
] as const;

export const languages = [
  { id: "en", label: "English", native: "Stories delivered in English" },
  { id: "hi", label: "हिन्दी", native: "दैनिक ब्रीफ हिंदी में" },
] as const;

export const voices = [
  { id: "aria", name: "Aria", locale: "en-GB", lang: "EN", style: "Warm · Unhurried · British", sample: "Good morning. Here is your briefing for today." },
  { id: "kai", name: "Kai", locale: "en-US", lang: "EN", style: "Crisp · Focused · American", sample: "Here's what moved overnight — in two minutes." },
  { id: "meera", name: "Meera", locale: "hi-IN", lang: "HI", style: "Bright · Curious · Indian", sample: "सुप्रभात। आज की ब्रीफिंग तैयार है।" },
] as const;

export type Story = {
  id: string;
  profession: string;
  minutes: number;
  tags: string[];
  source: string;
  sourceUrl: string;
  en: { title: string; summary: string; deepDive: string };
  hi: { title: string; summary: string; deepDive: string };
};

export const stories: Story[] = [
  {
    id: "s1",
    profession: "finance",
    minutes: 2,
    tags: ["markets", "india"],
    source: "BLOOMBERG",
    sourceUrl: "https://www.bloomberg.com",
    en: {
      title: "RBI holds rates, flags sticky food inflation",
      summary:
        "The Reserve Bank kept the repo rate unchanged. Food inflation remains the swing factor for the next two meetings.",
      deepDive:
        "Markets had priced a small cut. The statement emphasised transmission still in progress and patchy rural demand. Bond yields firmed. Watch cereal and vegetable prints next week.",
    },
    hi: {
      title: "आरबीआई ने दरें स्थिर रखीं, खाद्य महंगाई चिंता",
      summary: "रिजर्व बैंक ने रेपो दर नहीं बदली। अगली दो बैठकों में खाद्य महंगाई निर्णायक रहेगी।",
      deepDive:
        "बाजार कटौती की उम्मीद कर रहा था। बयान में कहा गया कि ट्रांसमिशन अभी जारी है। अनाज और सब्जी के आँकड़े देखें।",
    },
  },
  {
    id: "s2",
    profession: "finance",
    minutes: 1,
    tags: ["markets", "ai"],
    source: "REUTERS",
    sourceUrl: "https://www.reuters.com",
    en: {
      title: "IT majors guide cautiously into US budget season",
      summary: "TCS and Infosys flagged slower discretionary spend. Pipelines are healthy; conversion is stretching.",
      deepDive:
        "Cost-takeout deals are winning over transformation. BFSI is still the strongest vertical. Watch large-deal TCV and utilisation.",
    },
    hi: {
      title: "आईटी कंपनियों का अमेरिकी बजट सीजन पर सतर्क रुख",
      summary: "टीसीएस और इंफोसिस ने खर्च धीमा बताया। डील पाइपलाइन मजबूत है, क्लोजिंग देरी से हो रही है।",
      deepDive: "लागत-कटौती सौदे आगे हैं। बीएफएसआई सबसे मजबूत वर्टिकल बना हुआ है।",
    },
  },
  {
    id: "s3",
    profession: "finance",
    minutes: 2,
    tags: ["climate", "markets"],
    source: "REUTERS",
    sourceUrl: "https://www.reuters.com",
    en: {
      title: "Brent steadies as OPEC+ keeps extra barrels on ice",
      summary: "Crude held the $78–$81 band after producers delayed a supply increase.",
      deepDive:
        "The group is balancing weak Chinese demand against geopolitics. Indian OMCs get a window to rebuild inventory.",
    },
    hi: {
      title: "ओपेक+ ने आपूर्ति बढ़ाई नहीं, ब्रेंट स्थिर",
      summary: "उत्पादकों ने आपूर्ति बढ़ाने को टाला, कच्चा तेल 78–81 डॉलर पर रहा।",
      deepDive: "चीन की मांग कमजोर है। भारतीय ओएमसी स्टॉक बढ़ा सकती हैं।",
    },
  },
  {
    id: "s4",
    profession: "tech",
    minutes: 2,
    tags: ["ai", "startups"],
    source: "THE VERGE",
    sourceUrl: "https://www.theverge.com",
    en: {
      title: "OpenAI, Google, and the enterprise seat war",
      summary: "Enterprises are dual-sourcing models. Procurement now asks for evals and data residency, not tokens.",
      deepDive:
        "Assume model interchangeability. The moat is workflow, evaluation harnesses, and proprietary context.",
    },
    hi: {
      title: "ओपनएआई और गूगल की एंटरप्राइज सीट जंग",
      summary: "कंपनियाँ दो मॉडल चला रही हैं। खरीद अब टोकन नहीं, इवल और डेटा रेजिडेंसी पूछती है।",
      deepDive: "मॉडल बदल सकेंगे। असली बढ़त वर्कफ़्लो और अपने डेटा में है।",
    },
  },
  {
    id: "s4b",
    profession: "tech",
    minutes: 2,
    tags: ["ai", "science"],
    source: "THE VERGE",
    sourceUrl: "https://www.theverge.com",
    en: {
      title: "Anthropic ships Claude 4.5 with 2M-token memory and native tools.",
      summary:
        "Claude held entire codebases in mind while it built. Tool use is now first-class, not a plugin.",
      deepDive:
        "Context windows this large change how product teams store specs. Expect evals, not prompts, to become the real artefact.",
    },
    hi: {
      title: "एंथ्रोपिक ने क्लॉड 4.5 लॉन्च किया — 20 लाख टोकन मेमोरी",
      summary: "पूरा कोडबेस याद रखकर बिल्ड करता है। टूल यूज़ अब प्लगइन नहीं, मूल क्षमता है।",
      deepDive: "इतनी बड़ी कॉन्टेक्स्ट विंडो से स्पेक रखना बदल जाएगा। असली चीज़ प्रॉम्प्ट नहीं, इवल होगी।",
    },
  },
  {
    id: "s5",
    profession: "tech",
    minutes: 1,
    tags: ["ai", "science"],
    source: "TECHCRUNCH",
    sourceUrl: "https://techcrunch.com",
    en: {
      title: "GitHub Copilot usage hits a ceiling on review quality",
      summary: "Teams shipping with agents are spending more time on review than generation.",
      deepDive:
        "The bottleneck moved from writing code to verifying it. Invest in tests and evals before adding another model.",
    },
    hi: {
      title: "Copilot से कोड बढ़े, रिव्यू का बोझ और बढ़ा",
      summary: "एजेंट से शिप करने वाली टीमें जनरेशन से ज्यादा रिव्यू में समय दे रही हैं।",
      deepDive: "अड़चन लिखने से जाँच पर आ गई। नया मॉडल जोड़ने से पहले टेस्ट मजबूत करें।",
    },
  },
  {
    id: "s6",
    profession: "founder",
    minutes: 2,
    tags: ["startups", "india"],
    source: "INC42",
    sourceUrl: "https://inc42.com",
    en: {
      title: "A $180M Bengaluru round, with a quiet carve-out",
      summary: "A climate-fintech raised flat versus last year. Strategics took a product-team carve-out.",
      deepDive: "This is the new shape of down-round avoidance. Watch IP assignment and key-person clauses.",
    },
    hi: {
      title: "बेंगलुरु में 180 मिलियन डॉलर का राउंड, चुपचाप कार्व-आउट",
      summary: "क्लाइमेट-फिनटेक ने पिछले साल जितना ही जुटाया। रणनीतिक निवेशकों ने टीम ले ली।",
      deepDive: "डाउन-राउंड बचाने का नया तरीका। आईपी और की-पर्सन क्लॉज देखें।",
    },
  },
  {
    id: "s7",
    profession: "healthcare",
    minutes: 3,
    tags: ["health", "legal"],
    source: "THE HINDU",
    sourceUrl: "https://www.thehindu.com",
    en: {
      title: "CDSCO tightens adverse-event reporting for new biologics",
      summary: "Hospitals must file serious events within 24 hours for newly approved biologics.",
      deepDive:
        "Pharmacovigilance teams should update SOPs this week. Expect more queries on cold-chain logs.",
    },
    hi: {
      title: "सीडीएससीओ ने नई बायोलॉजिक्स पर रिपोर्टिंग कड़ी की",
      summary: "अस्पतालों को गंभीर घटना 24 घंटे में दर्ज करनी होगी।",
      deepDive: "फार्माकोविजिलेंस SOP इसी सप्ताह अपडेट करें। कोल्ड-चेन लॉग पर सवाल बढ़ेंगे।",
    },
  },
  {
    id: "s8",
    profession: "legal",
    minutes: 3,
    tags: ["legal", "politics"],
    source: "MINT",
    sourceUrl: "https://www.livemint.com",
    en: {
      title: "DPDP rules: consent managers get a go-live window",
      summary: "MeitY published a phased timeline for consent managers. Large fiduciaries start first.",
      deepDive: "Map data principals and purpose limitation now. Cross-border transfers remain the open item.",
    },
    hi: {
      title: "डीपीडीपी नियम: सहमति प्रबंधकों की समय-सीमा जारी",
      summary: "मेइटी ने चरणबद्ध समय-सारिणी दी। बड़े फिड्यूशरी पहले आएंगे।",
      deepDive: "डेटा प्रिंसिपल और उद्देश्य सीमा अभी मैप करें। सीमा-पार ट्रांसफर अभी खुला है।",
    },
  },
  {
    id: "s9",
    profession: "consulting",
    minutes: 2,
    tags: ["markets", "startups"],
    source: "BLOOMBERG",
    sourceUrl: "https://www.bloomberg.com",
    en: {
      title: "Boardrooms want fewer slides, more decision memos",
      summary: "Two large GCCs cut monthly strategy packs from 40 pages to a 4-page memo.",
      deepDive: "Clients will pay for choices with trade-offs, not another landscape scan.",
    },
    hi: {
      title: "बोर्ड कम स्लाइड, ज्यादा निर्णय मेमो चाहते हैं",
      summary: "दो बड़े जीसीसी ने मासिक पैक 40 पन्नों से 4 पन्ने कर दिए।",
      deepDive: "क्लाइंट ट्रेड-ऑफ वाले विकल्प खरीदेंगे, एक और लैंडस्केप स्कैन नहीं।",
    },
  },
  {
    id: "s10",
    profession: "policy",
    minutes: 2,
    tags: ["politics", "markets"],
    source: "REUTERS",
    sourceUrl: "https://www.reuters.com",
    en: {
      title: "Fed minutes hint at a September policy shift.",
      summary: "Officials flagged growing confidence that inflation is cooling toward target.",
      deepDive:
        "A September cut is back on the table if labour cools without a hard landing. Indian IT and rate-sensitive banks will reprice first.",
    },
    hi: {
      title: "फेड मिनट्स में सितंबर नीति बदलाव के संकेत",
      summary: "अधिकारियों ने कहा महंगाई लक्ष्य की ओर ठंडी हो रही है।",
      deepDive: "श्रम बाजार नरम रहा तो सितंबर कटौती संभव है। भारतीय आईटी और बैंक पहले प्रतिक्रिया देंगे।",
    },
  },
  {
    id: "s11",
    profession: "tech",
    minutes: 2,
    tags: ["startups", "ai"],
    source: "TECHCRUNCH",
    sourceUrl: "https://techcrunch.com",
    en: {
      title: "Indian AI labs race to ship on-device models",
      summary: "Three Bengaluru teams posted sub-3B models that run offline on mid-range Androids.",
      deepDive:
        "The pitch is privacy and latency, not benchmark bragging. Watch distribution deals with handset OEMs this quarter.",
    },
    hi: {
      title: "भारतीय एआई लैब्स ऑन-डिवाइस मॉडल की होड़ में",
      summary: "बेंगलुरु की तीन टीमें मिड-रेंज एंड्रॉइड पर ऑफलाइन चलने वाले छोटे मॉडल लाईं।",
      deepDive: "दावा बेंचमार्क नहीं, प्राइवेसी और स्पीड है। ओईएम डील्स देखें।",
    },
  },
  {
    id: "s12",
    profession: "founder",
    minutes: 2,
    tags: ["india", "startups"],
    source: "INC42",
    sourceUrl: "https://inc42.com",
    en: {
      title: "SaaS founders delay US hiring until rupee hedges settle",
      summary: "Two payroll platforms paused California offers after a sharp rupee swing.",
      deepDive: "Treasury policy is now a hiring decision. Boards want a 90-day FX collar before headcount.",
    },
    hi: {
      title: "रुपया हेज के बाद ही अमेरिकी हायरिंग",
      summary: "रुपये के झटके के बाद दो पेरोल प्लेटफॉर्म ने कैलिफोर्निया ऑफर रोक दिए।",
      deepDive: "ट्रेजरी अब हायरिंग का हिस्सा है। बोर्ड 90 दिन का एफएक्स कॉलर चाहते हैं।",
    },
  },
];

export type LocalizedStory = {
  id: string;
  profession: string;
  minutes: number;
  tags: string[];
  source: string;
  sourceUrl: string;
  title: string;
  summary: string;
  deepDive: string;
};

export function buildBriefing(
  profession: string,
  language: string,
  duration: number,
  topicIds: string[] = [],
): LocalizedStory[] {
  const lang = language === "hi" ? "hi" : "en";
  const localize = (s: (typeof stories)[number]): LocalizedStory => {
    const copy = s[lang];
    return {
      id: s.id,
      profession: s.profession,
      minutes: s.minutes,
      tags: [...s.tags],
      source: s.source,
      sourceUrl: s.sourceUrl,
      title: copy.title,
      summary: copy.summary,
      deepDive: copy.deepDive,
    };
  };
  const score = (s: (typeof stories)[number]) => {
    let n = s.profession === profession ? 8 : 0;
    if (topicIds.length) n += s.tags.filter((t) => topicIds.includes(t)).length * 4;
    return n;
  };
  const ranked = [...stories].sort((a, b) => score(b) - score(a));
  let mins = 0;
  const picked: LocalizedStory[] = [];
  for (const s of ranked) {
    if (mins >= duration) break;
    picked.push(localize(s));
    mins += s.minutes;
  }
  return picked.length ? picked : ranked.slice(0, 4).map(localize);
}

export function voiceForLanguage(language: string) {
  return language === "hi" ? "meera" : "aria";
}
