# Nuzio AI

Personalised audio news for Indian professionals. Dark Uber-style app with login, onboarding, and a morning brief player.

## Demo login

| | |
|---|---|
| **Email** | `demo@nuzio.app` |
| **Password** | `nuzio123` |

On the login screen you can also tap **Use demo account** or **Continue with Google**.

## Run locally

```bash
npm install
npm run dev
```

- Web: http://127.0.0.1:4173/
- API: http://127.0.0.1:8787/

If 4173 is taken, Vite will pick the next free port (for example 4176).

## Flow

Splash → language & location → login → profession → niches → narrator voice → brief time → notifications → you’re ready → **Brief / Discover / Settings**

The demo user is **Aarav Sharma** (Technology, Mumbai) with a 10-minute English brief narrated by Aria.
